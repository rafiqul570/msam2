<?php
   spl_autoload_register(function($class_name){
   include "../classes/".$class_name.".php";
});

error_reporting(0);
 
 $user = new User();

  if (isset($_GET['id'])) {
     $userid = (int)$_GET['id'];
  }
    
    	
    	if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['Login'])) {
    		$msg = $user->userLogin($_POST);
    }

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>phpfremwork</title>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="lib/font-awesome/css/font-awesome.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Kaisei+Decol&family=Oswald&display=swap">
</head>
<body> 
  <div class="container">
      <div class="row my-5">
        <div class="col-md-6 m-auto"> 
          <?Php 
            if (isset($_GET['error_msg'])) {
               $msg =   $_GET['error_msg'];
               echo $msg;
             }

           ?>
          <div class="card bg-light p-3">
          <div class="py-2 pb-3 m-auto">
             <h3>User Login</h3> 
          </div> 
            
           <form action="<?php $_SERVER['PHP_SELF']?>" method="POST">
              <div class="row mb-4">
                <label for="inputEmail3" class="col-sm-3 col-form-label">Username</label>
                <div class="col-sm-7">
                  <input type="text" class="form-control" id="inputEmail3" name="username">
                </div>
              </div>
              <div class="row mb-3">
                <label for="inputPassword3" class="col-sm-3 col-form-label">Password</label>
                <div class="col-sm-7">
                  <input type="password" class="form-control" id="inputPassword3" name="password">
                </div>
              </div>
              <div class="row mb-4">
                <label for="inputPassword3" class="col-sm-3 col-form-label"></label>
                <div class="col-sm-7">
                  <a class="forgot-pass" href="changepass.php">Forgot Password</a>
                </div>
              </div>
             <button type="submit" class="btn btn-info btn-block mb-5" name="Login">Sign In</button>
            </form>
            <div class="mg-t-60 tx-center">Not yet a member? <a href="register.php" class="tx-info forgot-pass">Sign Up</a></div> 
          </div>  
        </div>    
      </div>
  </div>

<!-- JS-FILE --> 
<script src="js/jquery.js" type="text/javascript"></script> 
<script src="js/bootstrap.js" type="text/javascript"></script> 
<script src="js/main.js" type="text/javascript"></script> 
</body>
</html>