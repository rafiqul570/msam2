function calculate() {   
     if(isNaN(document.forms["myform"]["qty"].value) || document.forms["myform"]["qty"].value=="") {   
     var text1 = 0;   
     } else {   
     var text1 = parseInt(document.forms["myform"]["qty"].value);   
     }   
     if(isNaN(document.forms["myform"]["Cost"].value) || document.forms["myform"]["Cost"].value=="") {   
     var text2 = 0;   
     } else {   
     var text2 = parseFloat(document.forms["myform"]["Cost"].value);   
     }   
     document.forms["myform"]["textbox5"].value = (text1*text2);   
     }  