<?php  
include_once 'Institution.php'; 
  
?>
<?php
spl_autoload_register(function($class_name){
include "../../classes/".$class_name.".php";
});

//error_reporting(0);
class Admission{

  private $db;

  public function __construct(){
    $this->db = new Database();
      
   }


//Insert DATA
 public function insertStudent($data){
    $name = $data['name'];
    $fname = $data['fname'];
    $phone1 = $data['phone1'];
    $mname = $data['mname'];
    $phone2 = $data['phone2'];
    $p_village = $data['p_village'];
    $p_post = $data['p_post'];
    $p_upazila = $data['p_upazila'];
    $p_district = $data['p_district'];
    $c_village = $data['c_village'];
    $c_post = $data['c_post'];
    $c_upazila = $data['c_upazila'];
    $c_district = $data['c_district'];
    $b_date = $data['b_date'];
    $bid = $data['bid'];
    $f_occupation = $data['f_occupation'];
    $f_nid = $data['f_nid'];
    $m_occupation = $data['m_occupation'];
    $m_nid = $data['m_nid'];
    $admi_class = $data['admi_class'];
    $admi_date = $data['admi_date'];
    $admi_roll = $data['admi_roll'];
    $uniqid = $data['uniqid'];
    $last_ins_name = $data['last_ins_name'];
    $institution = $data['institution'];
  
  //upload image
    $file_name = $_FILES['image']['name'];
    $file_size = $_FILES['image']['size'];
    $tmp_name  = $_FILES['image']['tmp_name'];
    $permited  = array('jpeg', 'jpg', 'png', 'gif');
    $div = explode(".", $file_name);
    $file_ext = strtolower(end($div));
    $file_check = in_array($file_ext, $permited);
    $image = uniqid().$file_ext;
    $uploaded_image = '../uploads/image/'.$image;
            
  if ($name == "" || $fname == "" || $phone1 == "" || $mname == "" || $phone2 == "" || $p_village == "" || $p_post == "" || $p_upazila == "" || $p_district == "" || $c_village == "" || $c_post == "" || $c_upazila == "" || $c_district == "" || $b_date == "" || $bid == "" || $f_occupation == "" || $f_nid == "" || $m_occupation == "" || $m_nid == "" || $admi_class == "" || $admi_roll == "" || $uniqid == "" || $admi_date == "" || $last_ins_name == "" || $institution == "" || $image == "" ) {
        
      $msg = "<div class='alert  alert-success alert-dismissible fade show' role='alert'>
                  <span class='badge badge-pill badge-success'> Error !</span> Field must not be Empty!
                  <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                      <span aria-hidden='true'>&times;</span>
                  </button>
              </div>";
    
         return $msg; 
   
 } 

  if (empty($file_name)){
    $msg = '<div class="alert alert-danger alert-dismissible">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
             <strong>Sorry !</strong> Please Select any Image .
            </div>';
    
          return $msg; 
  
     
   }elseif($file_size > 304803456){

    $msg = '<div class="alert alert-danger alert-dismissible">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
             <strong>Error !</strong> Image size should be less then 3KB
            </div>';
    
          return $msg; 

   }elseif($file_check === false) {
    
        
        $msg = '<div class="alert alert-danger alert-dismissible">
              <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
             <strong>Sorry !</strong>You can upload only  -  ( jpeg, jpg, png, gif )
            </div>';
  
      return $msg;  
    
    }else{
    
    
   move_uploaded_file($tmp_name, $uploaded_image);

   
   $query = "INSERT INTO admission (name,fname,phone1,mname,phone2,p_village,p_post,p_upazila,p_district,c_village,c_post,c_upazila,c_district,b_date,bid,f_occupation,f_nid,m_occupation,m_nid,admi_class,admi_date,admi_roll,uniqid,last_ins_name,institution,image) VALUES ('$name', '$fname', '$phone1', '$mname', '$phone2', '$p_village', '$p_post', '$p_upazila', '$p_district', '$c_village', '$c_post', '$c_upazila', '$c_district', '$b_date', '$bid', '$f_occupation', '$f_nid', '$m_occupation', '$m_nid', '$admi_class', '$admi_date', '$admi_roll', '$uniqid', '$last_ins_name', '$institution','$image');";
    
    $result = $this->db->insert($query);

   if ($result) {

            $msg = '<div class="alert alert-danger alert-dismissible">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
             <strong>Success !</strong> Data Inserte Successfully.
            </div>';
  
       return $msg;
     
       
   }else{

        $msg = '<div class="alert alert-danger alert-dismissible">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
         <strong>Error !</strong> Data Not Inserted.
        </div>';
  
       return $msg; 
     }
 
    
    }

  }
  
  //Select data in index page (Admission) 
    public function getAdmissionData(){
      $query = "SELECT * FROM admission ORDER BY id DESC";
            $result = $this->db->select($query);
            return $result;

 }

  //Select data in View page (Admission) 
    public function getAdmissionViewData($id){
      $query = "SELECT * FROM admission WHERE id = '$id' ";
            $result = $this->db->select($query);
            return $result;

    }

//Select data in Update page (Admission)
 
    public function getAdmissionUpdateData($id){
      
    $sql = "SELECT * FROM admission WHERE id = '$id' LIMIT 1";
        $query = $this->db->select($sql);
                $result = mysqli_fetch_array($query);
                return $result;
     }


//Update Image/Data
   public function updateAdmission($id, $data){
      $sql = "SELECT * FROM admission WHERE id = '$id'";
      $result = $this->db->select($sql);
      $row = mysqli_fetch_array($result);
      
      $name = $data['name'];
      $fname = $data['fname'];
      $phone1 = $data['phone1'];
      $mname = $data['mname'];
      $phone2 = $data['phone2'];
      $p_village = $data['p_village'];
      $p_post = $data['p_post'];
      $p_upazila = $data['p_upazila'];
      $p_district = $data['p_district'];
      $c_village = $data['c_village'];
      $c_post = $data['c_post'];
      $c_upazila = $data['c_upazila'];
      $c_district = $data['c_district'];
      $b_date = $data['b_date'];
      $bid = $data['bid'];
      $f_occupation = $data['f_occupation'];
      $f_nid = $data['f_nid'];
      $m_occupation = $data['m_occupation'];
      $m_nid = $data['m_nid'];
      $admi_class = $data['admi_class'];
      $admi_date = $data['admi_date'];
      $admi_roll = $data['admi_roll'];
      $uniqid = $data['uniqid'];
      $last_ins_name = $data['last_ins_name'];
    
        
      $img = $_FILES['image'];
      $tmp_name = $img['tmp_name'];
      $image = uniqid().$_FILES['image']['name'];
      $fileName = '../uploads/image/'.$image;
      if ($img['size'] > 1) {
        if (file_exists("../uploads/image/".$row['image']) && !empty($row['image'])) {
          unlink("../uploads/image/".$row['image']);
        }

      move_uploaded_file($tmp_name, $fileName);

$query = "UPDATE admission SET name = '$name', fname = '$fname', phone1 = '$phone1',
    mname = '$mname', phone2 = '$phone2', p_village = '$p_village', p_post = '$p_post', 
    p_upazila = '$p_upazila', p_district = '$p_district', c_village = '$c_village',
    c_post = '$c_post', c_upazila = '$c_upazila', c_district = '$c_district',
    b_date = '$b_date', bid = '$bid', f_occupation = '$f_occupation', f_nid= '$f_nid',
    m_occupation = '$m_occupation', m_nid = '$m_nid', admi_class = '$admi_class', 
    admi_date = '$admi_date', admi_roll = '$admi_roll', uniqid = '$uniqid', 
    last_ins_name = '$last_ins_name', image = '$image' WHERE id = '$id' ";
    
    
    }else{
    

$query = "UPDATE admission SET name = '$name', fname = '$fname', phone1 = '$phone1',
    mname = '$mname', phone2 = '$phone2', p_village = '$p_village', p_post = '$p_post', 
    p_upazila = '$p_upazila', p_district = '$p_district', c_village = '$c_village',
    c_post = '$c_post', c_upazila = '$c_upazila', c_district = '$c_district',
    b_date = '$b_date', bid = '$bid', f_occupation = '$f_occupation', f_nid= '$f_nid',
    m_occupation = '$m_occupation', m_nid = '$m_nid', admi_class = '$admi_class', 
    admi_date = '$admi_date', admi_roll = '$admi_roll', uniqid = '$uniqid', 
    last_ins_name = '$last_ins_name' WHERE id = '$id' ";
    
    }

    $result = $this->db->update($query);

    if ($result) {
      header("Location: all-student.php?success_msg=".urlencode('
             <div class="alert alert-danger alert-dismissible">
             <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
              <strong>Success !</strong> Data Update Successfully.
             </div>

        '));
   

  }else{

      header("Location: update.php?error_msg=".urlencode('

            <div class="alert alert-danger alert-dismissible">
             <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
              <strong>Success !</strong> Data Not Update.
             </div>

        '));
  
  }
   

  } 


//Delete Admission  
  public function deleteAdmission($id){
        
        $img = "SELECT * FROM admission WHERE id = '$id'";
        $result = $this->db->select($img);
            $row = mysqli_fetch_array($result);
            $image = $row['image'];
            if(!empty($image)){
            unlink("../uploads/image/".$image); 
            }
           
            $query = "DELETE FROM admission WHERE id = '$id'";
            $result = $this->db->delete($query);   
            
       
        if ($result){
          $msg = '<div class="alert alert-danger alert-dismissible">
              <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
               <strong>Success !</strong> Data Delete Successfully.
              </div>';
      
           return $msg; 
          
     
    }else{

      $msg = '<div class="alert alert-danger alert-dismissible">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                 <strong>Error !</strong> Data Not Deleted.
                </div>';
        
             return $msg; 
    
    }
    
        }


}

?>