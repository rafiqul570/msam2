<?php
include_once 'Session.php';
?>

<?php
spl_autoload_register(function($class_name){
include "../../classes/".$class_name.".php";
});

//error_reporting(0);
 

class User{

private $db;

  public function __construct(){
    $this->db = new Database();
  }


public function userRegistration($data){
		$name = $data['name'];
		$username = $data['username'];
		$email = $data['email'];
		$phone = $data['phone'];
		$role = $data['role'];
		$password = md5($data['password']);
		

	if ($name == "" || $username == "" || $email == "" || $phone == "" || $role == "" || $password == "") {
		    	
	    	$msg = "<div class='alert  alert-success alert-dismissible fade show' role='alert'>
                    <span class='badge badge-pill badge-success'> Error !</span> Field must not be Empty!
                    
                </div>";
			
		       return $msg; 
		 
	 } 

	 if (strlen($username ) < 3) {
	 	   
			$msg = "<div class='alert  alert-success alert-dismissible fade show' role='alert'>
                    <span class='badge badge-pill badge-success'> Error !</span> Username is too short.
                </div>";
			
		    return $msg;	

	}elseif(preg_match('/[^a-z0-9_-]+/i', $username)) {
			
	       $msg = '<div class="alert alert-danger alert-dismissible">
             <strong></strong> The Username must only contain alphanumerically, deshes and underscores !
            </div>'; 

	               return $msg;
	}

	if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
		 	
			 $msg = "<div class='alert  alert-success alert-dismissible fade show' role='alert'>
	                    <span class='badge badge-pill badge-success'> Error !</span> The email address is not valid !
	                </div>"; 
	               return $msg;
		 }

	$query = "SELECT * FROM user WHERE email = '$email' AND username = '$username' AND phone = '$phone' LIMIT 1";
	$chk_email = $this->db->select($query);

	if ($chk_email !== false) {
			 	
	$msg = "<div class='alert  alert-success alert-dismissible fade show' role='alert'>
            <span class='badge badge-pill badge-success'> Error !</span> The email address/username/phone number already Exist!
        	</div>"; 

        return $msg;
			
	}else{
	

   
   $sql = "INSERT INTO user (name,username,email,phone,password,role) VALUES ('$name', '$username','$email', '$phone', '$password','$role')";
       $result = $this->db->insert($sql);
		
	if ($result) {
			
		  $msg = '<div class="alert alert-danger alert-dismissible">
             <strong> Success !</strong> Registration Successfully ! Please Login.
            </div>';
			
		    return $msg;
	   
		   
	}else{

     		$msg = '<div class="alert alert-danger alert-dismissible">
             <strong>Error !</strong> Data Not Inserte.
            </div>';
			
		    return $msg;  
	 
	
	   }
	
    } 
 
}

 //====== LOGIN ADMIN START ===============//

 public function adminLogin($data){
	    
		$email = $data['email'];
		$password = md5($data['password']);
		
	   if ($email == "" || $password == "") {	
    	
		      $msg = "<div class='alert  alert-success alert-dismissible fade show' role='alert'>
                    <span class='badge badge-pill badge-success'> Error !</span> Field must not be Empty!
                	</div>";
			
		       return $msg;  
	 
		 }    
   		

	$query = "SELECT * FROM user WHERE email = '$email' AND password = '$password' LIMIT 1";
		$result = $this->db->select($query);
         if($result->num_rows > 0){
            $value = $result->fetch_assoc();
            Session::init();
		  	Session::set("login", true);
		  	Session::set("id", $value['id']);
		  	Session::set("name", $value['name']);
		  	Session::set("username", $value['username']);
		  	Session::set("role", $value['role']);
          	
          	if($value['role'] == 1){
          	 
          	  header("Location: index.php?success_msg=".urlencode('
	             <div class="alert alert-danger alert-dismissible">
	             <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
	              <strong>Success !</strong> You are logedin.
	             </div> '));	
          	}
          	
          	if($value['role'] == 0){
          	  header("Location: login.php?error_msg=".urlencode('
	             <div class="alert alert-danger alert-dismissible">
	              <strong>Error !</strong> The Email address is not valid ! Please Try Again.
	             </div> '));	
	          	}
          }		
     
	}
 
 //====== LOGIN USER START ===============//
    public function userLogin($data){
		$username = $data['username'];
		$password = md5($data['password']);
		
	   if ($username == "" || $password == "") {	
    	
		      $msg = "<div class='alert  alert-success alert-dismissible fade show' role='alert'>
                    <span class='badge badge-pill badge-success'> Error !</span> Field must not be Empty!
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                        <span aria-hidden='true'>&times;</span>
                    </button>
                </div>";
			
		       return $msg;  
	 
		 }    
   		

	$query = "SELECT * FROM user WHERE username = '$username' AND password = '$password' LIMIT 1";
		$result = $this->db->select($query);
         if($result->num_rows > 0){
            $value = $result->fetch_assoc();
            Session::init();
		  	Session::set("login", true);
		  	Session::set("id", $value['id']);
		  	Session::set("name", $value['name']);
		  	Session::set("username", $value['username']);
		  	Session::set("role", $value['role']);
          	
          	if($value['role'] == 0){
          	 
          	  header("Location: ../admin/index.php?success_msg=".urlencode('
	             <div class="alert alert-danger alert-dismissible">
	             <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
	              <strong>Success !</strong> You are logedin.
	             </div> '));	
          	}
          	
          	if($value['role'] == 1){
          	  header("Location: login.php?error_msg=".urlencode('
	             <div class="alert alert-danger alert-dismissible">
	              <strong>Error !</strong> The Email address is not valid ! Please Try Again.
	             </div> '));	
	          	}
          }		
 
   }


}

?>
