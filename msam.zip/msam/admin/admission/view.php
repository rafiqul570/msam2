<?php
  spl_autoload_register(function($class_name){
   include "../../classes/".$class_name.".php";
});

//error_reporting(0);
 
$admission = new Admission();

?>
<?php
if (isset($_GET['id'])) {
      $id = (int)$_GET['id']; 
  
  $allStudent = $admission->getAdmissionViewData($id);

}
?>
<?php include '../header.php';?>

   <!-- ########## START: MAIN PANEL ########## -->
    <div class="sl-mainpanel"> 
      <div class="sl-pagebody">
        <div class="row row-sm">
          <div class="col-xl-12 mg-t-25 mg-xl-t-0">
            <div class="card pd-20 pd-sm-40 form-layout form-layout-5">
              <div class="row">
                <div class="col-md-4">
                   <h6 class="tx-gray-800 tx-uppercase tx-bold tx-20 pb-3">Student Data</h6>
                </div>
                <div class="col-md-8 ml-auto">
                  <a class="btn btn-primary text-white" href="add-student.php">Add Student</a>
                
                  <a class="btn btn-primary text-white" href="all-student.php">All Student</a>
                </div>
              </div>

         <?php while($row = mysqli_fetch_array($allStudent)) { ?>
            
            <div class="row mb-">
            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black">ছাত্র/ছাত্রীর নাম</h6></label>
            <div class="col-sm-4 pt-2">
              <h6 class="name">: <td class=""><?php echo $row['name']; ?></td></h6>
            </div>

            <label for="inputEmail3" class="col-sm-1 col-form-label"><h6 class="text-black">ছবি</h6></label>
            <div class="col-sm-4 img">
              <img style="width: 50px; height: 50px"; src="../uploads/image/<?php echo $row['image']; ?>"></td>
            </div>
            </div>

            <div class="row mb-">
            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black">পিতার নাম</h6></label>
            <div class="col-sm-4 pt-2">
              <h6 class="fname">: <td class=""><?php echo $row['fname']; ?></td></h6>
            </div>
              
            <label for="inputEmail3" class="col-sm-1 col-form-label"><h6 class="text-black">ফোন</h6></label>
            
            <div class="col-sm-4 pt-2">
              <h6 class="phone">: <td class="text-black"><?php echo $row['phone1']; ?></td></h6>
            </div>
            </div>

           <div class="row">
            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black">মাতার নাম</h6></label>
           
            <div class="col-sm-4 pt-2">
              <h6 class="mname">: <td class="text-black"><?php echo $row['mname']; ?></td></h6>
            </div>

            <label for="inputEmail3" class="col-sm-1 col-form-label"><h6 class="text-black">ফোন</h6></label>
            
            <div class="col-sm-4 pt-2">
              <h6 class="phone">: <td class="text-black"><?php echo $row['phone2']; ?></td></h6>
            </div>
            </div>
            
            <div class="row my-3 pl-3 tx-primary tx-bold">স্থায়ী ঠিকানা -</div>
            <div class="row mb-3">
            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black">গ্রাম</h6></label>
            
            <div class="col-sm-4 pt-2">
              <h6 class="vill">: <td class="text-black"><?php echo $row['p_village']; ?></td></h6>
            </div>

            <label for="inputEmail3" class="col-sm-1 col-form-label"><h6 class="text-black">ডাকঘর</h6></label>
            
            <div class="col-sm-4 pt-2">
              <h6 class="post">: <td class="text-black"><?php echo $row['p_post']; ?></td></h6>
            </div>
            </div>

            <div class="row mb-">
            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black ">উপজেলা</h6></label>
            
            <div class="col-sm-4 pt-2">
              <h6 class="upa">: <td class="text-black"><?php echo $row['p_upazila']; ?></td></h6>
            </div>

            <label for="inputEmail3" class="col-sm-1 col-form-label"><h6 class="text-black">জেলা</h6></label>
           
            <div class="col-sm-4 pt-2">
              <h6 class="dis">: <td class="text-black"><?php echo $row['p_district']; ?></td></h6>
            </div>
            </div>

            <div class="row my-3 pl-3 tx-primary tx-bold">বর্তমান ঠিকানা -</div>
            <div class="row mb-3">
            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black">গ্রাম</h6></label>
            
            <div class="col-sm-4 pt-2">
              <h6 class="vill">: <td class="text-black"><?php echo $row['c_village']; ?></td></h6>
            </div>

            <label for="inputEmail3" class="col-sm-1 col-form-label"><h6 class="text-black">ডাকঘর</h6></label>
           
            <div class="col-sm-4 pt-2">
              <h6 class="post">: <td class="text-black"><?php echo $row['c_post']; ?></td></h6>
            </div>
            </div>

            <div class="row mb-1">
            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black">উপজেলা</h6></label>
            
            <div class="col-sm-4 pt-2">
              <h6 class="upa">: <td class="text-black"><?php echo $row['c_upazila']; ?></td></h6>
            </div>

            <label for="inputEmail3" class="col-sm-1 col-form-label"><h6 class="text-black">জেলা</h6></label>
            
            <div class="col-sm-4 pt-2">
              <h6 class="dis">: <td class="text-black"><?php echo $row['c_district']; ?></td></h6>
            </div>
            </div>
            
            <div class="row mb-1">
            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black">জন্ম তারিখ</h6></label>
            
            <div class="col-sm-3 pt-2">
              <h6 class="birth_d">: <td class="text-black"><?php echo $row['b_date']; ?></td></h6>
            </div>

            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black">জন্ম নিবন্ধন নম্বর</h6></label>
            
            <div class="col-sm-4 pt-2">
              <h6 class="bid">: <td class="text-black"><?php echo $row['bid']; ?></td></h6>
            </div>
            </div>

            <div class="row mb-1 view">
            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black">পিতার পেশা</h6></label>
           
            <div class="col-sm-3 pt-2">
              <h6 class="focc">: <td class="text-black"><?php echo $row['f_occupation']; ?></td></h6>
            </div>

            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black">এন আইডি নম্বর</h6></label>
            
            <div class="col-sm-4 pt-2">
              <h6 class="nid">: <td class="text-black"><?php echo $row['f_nid']; ?></td></h6>
            </div>
            </div>


            <div class="row mb-1">
            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black">মাতার পেশা</h6></label>
            
            <div class="col-sm-3 pt-2">
              <h6 class="mocc">: <td class="text-black"><?php echo $row['m_occupation']; ?></td></h6>
            </div>

            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black">এন আইডি নম্বর</h6></label>
           
            <div class="col-sm-4 pt-2">
              <h6 class="nid">: <td class="text-black"><?php echo $row['m_nid']; ?></td></h6>
            </div>
            </div>

            <div class="row mb-1">
            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black">ভর্তি ইচ্ছুক শ্রেনী</h6></label>
            
            <div class="col-sm-3 pt-2">
              <h6 class="admi_class">: <td class="text-black"><?php echo $row['admi_class']; ?></td></h6>
            </div>

            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black">ভর্তি তারিখ</h6></label>
            
            <div class="col-sm-4 pt-2">
              <h6 class="admi_date">: <td class="text-black"><?php echo $row['admi_date']; ?></td></h6>
            </div>
            </div>

            <div class="row mb-1">
            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black">ভর্তি রোল</h6></label>
           
            <div class="col-sm-3 pt-2">
              <h6 class="admi_roll">: <td class="text-black"><?php echo $row['admi_roll']; ?></td></h6>
            </div>

            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black">ইউনিক আইডি</h6></label>
            
            <div class="col-sm-4 pt-2">
              <h6 class="uniqid">: <td class="text-black"><?php echo $row['uniqid']; ?></td></h6>
            </div>
            </div>

            <div class="row mb-1">
            <label for="inputEmail3" class="col-sm-3 col-form-label"><h6 class="text-black">সর্বশেষ শিক্ষা প্রতিষ্ঠানের নাম</h6></label>
            
            <div class="col-sm-4 pt-2">
              <h6 class="last_ins">: <td class="text-black"><?php echo $row['last_ins_name']; ?></td></h6>
            </div>
            </div>
            <?php } ?>
            </div><!-- card -->
          </div><!-- col-6 -->
        </div><!-- row -->
      </div><!-- sl-pagebody -->
    </div><!-- sl-mainpanel -->
    <!-- ########## END: MAIN PANEL ########## -->

   <?php include '../footer.php'; ?>
