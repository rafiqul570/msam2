<?php
   include_once("../classes/Session.php");
   session_start();
   Session::init();
   if (isset($_GET['action']) && $_GET['action'] == "logout") {
   Session::destroy();
}



if (! isset($_SESSION['destroy'])){
   if($value['role'] == 1){
   header ('Location:login.php');
  }
  if($value['role'] == 0){
  	header ('Location:../public/login.php');
  }
}

?>