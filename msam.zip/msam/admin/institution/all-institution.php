<?php
  spl_autoload_register(function($class_name){
   include "../../classes/".$class_name.".php";
});

//error_reporting(0);
  
$institution = new Institution();

//Delete Student
if (isset($_GET['id'])) {
    $id =   $_GET['id'];

    $msg = $institution->deleteInstitution($id);

    }

?>

  <?php include '../header.php';?>
  
    <!-- ########## START: MAIN PANEL ########## -->
    <div class="sl-mainpanel">

      <div class="sl-pagebody">
      <!-- <h6 class="tx-gray-800 tx-uppercase tx-bold tx-14 mg-b-10">All Student</h6> -->
      
      <?php
        if (isset($msg)) {
            echo $msg;
        }
      ?>
      
      <?Php 
      if (isset($_GET['success_msg'])) {
         $msg =   $_GET['success_msg'];
         echo $msg;
       }
      ?>

        <div class="row row-sm">
          <div class="col-xl-12 mg-t-25 mg-xl-t-0">
            <div class="card pd-20 pd-sm-40 form-layout form-layout-5">
              <div class="row">
                <div class="col-md-4">
                  <h6 class="tx-gray-800 tx-uppercase tx-bold tx-20 pb-3">all Institution</h6>
                </div>
                <div class="col-md-4"></div>
                <div class="col-md-4 view1">
                  <a class="btn btn-primary text-white" href="add-institution.php">add</a>
                </div>
              </div>
              
              <div class="table-wrapper">
              <table id="datatable1" class="table datatables-responsive">
              <thead>
                <tr>
                  <th class="wd-20p tx-center">Serial No</th>
                  <th class="wd-50p tx-center">শিক্ষা প্রতিষ্ঠানের নাম</th>
                  <th class="wd-30p tx-center">Action</th>
                </tr>
              </thead>
              <tbody>
                <?php
                  $allIns = $institution->getAllInstitutionData();
                  if ($allIns) {
                    $i = 0;
                    foreach ( $allIns as $row) {
                    $i++;
                          
                  ?> 
                <tr>
                  <td class="tx-center"><?php echo $i; ?></td>
                  <td class="tx-center"><?php echo $row['ins_name']; ?></td>
                  <td class="tx-center">
                   <a class="btn btn-info btn-sm" href="update.php?id=
                    <?php echo $row ['id']; ?>">Edit</a>
                  
                    <a class="btn btn-danger btn-sm" onclick="return confirm('Are you sure ?')" href="?id=<?php echo $row['id']; ?>">Delete</a>

                    <a class="btn btn-info btn-sm" href="view.php?id=
                    <?php echo $row['id']; ?>">view</a>
                  </td>
                </tr>
                <?php } } ?>
              </tbody>
            </table>
           </div><!-- table-wrapper -->
          </div><!-- card -->
        </div><!-- col-6 -->
      </div><!-- row -->
    </div><!-- sl-pagebody -->
  </div><!-- sl-mainpanel -->
    <!-- ########## END: MAIN PANEL ########## -->
             
    
    <script src="../lib/jquery/jquery.js"></script>
    <script src="../lib/popper.js/popper.js"></script>
    <script src="../lib/bootstrap/bootstrap.js"></script>
    <script src="../lib/perfect-scrollbar/js/perfect-scrollbar.jquery.js"></script>
    <script src="../lib/highlightjs/highlight.pack.js"></script>
    <script src="../lib/datatables/jquery.dataTables.js"></script>
    <script src="../lib/datatables-responsive/dataTables.responsive.js"></script>
    <script src="../lib/select2/js/select2.min.js"></script>
    <script src="../js/starlight.js"></script>
    
    <script>
      $(function(){
        'use strict';

        $('#datatable1').DataTable({
          responsive: true,
          language: {
            searchPlaceholder: 'Search...',
            sSearch: '',
            lengthMenu: '_MENU_ items/page',
          }
        });

        $('#datatable2').DataTable({
          bLengthChange: false,
          searching: false,
          responsive: true
        });

        // Select2
        $('.dataTables_length select').select2({ minimumResultsForSearch: Infinity });

      });
    </script>

  </body>
</html>
       