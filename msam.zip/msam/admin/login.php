<?php
   spl_autoload_register(function($class_name){
   include "../classes/".$class_name.".php";
});

 error_reporting(0);
 
 $user = new User();

  if (isset($_GET['id'])) {
     $userid = (int)$_GET['id'];
  }
 
    
  if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['Login'])) {
      $msg = $user->adminLogin($_POST);
  }

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Twitter -->
    <meta name="twitter:site" content="@themepixels">
    <meta name="twitter:creator" content="@themepixels">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Starlight">
    <meta name="twitter:description" content="Premium Quality and Responsive UI for Dashboard.">
    <meta name="twitter:image" content="http://themepixels.me/starlight/img/starlight-social.png">

    <!-- Facebook -->
    <meta property="og:url" content="http://themepixels.me/starlight">
    <meta property="og:title" content="Starlight">
    <meta property="og:description" content="Premium Quality and Responsive UI for Dashboard.">

    <meta property="og:image" content="http://themepixels.me/starlight/img/starlight-social.png">
    <meta property="og:image:secure_url" content="http://themepixels.me/starlight/img/starlight-social.png">
    <meta property="og:image:type" content="image/png">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="600">

    <!-- Meta -->
    <meta name="description" content="Premium Quality and Responsive UI for Dashboard.">
    <meta name="author" content="ThemePixels">

    <title>Blog</title>

    <!-- vendor css -->
    <link href="lib/font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="lib/Ionicons/css/ionicons.css" rel="stylesheet">


    <!-- Starlight CSS -->
    <link rel="stylesheet" href="css/starlight.css">
  </head>

  <body class="bg-dark">

    <div class="d-flex align-items-center justify-content-center bg-sl-primary ht-100v">
      <div class="login-content">

        <?Php 
          if (isset($_GET['error_msg'])) {
             $msg =   $_GET['error_msg'];
             echo $msg;
           }

        ?>

      <div class="login-wrapper wd-400 wd-xs-450 pd-25 pd-xs-40 bg-white">
        <div class="signin-logo tx-center tx-24 tx-bold tx-inverse"><span class="tx-info tx-normal">Admin Login</span></div>
        <div class="tx-center mg-b-60"></div>
        
      <form action="<?php $_SERVER['PHP_SELF']?>" method="POST">
        <div class="row mb-4">
          <label for="inputEmail3" class="col-sm-3 col-form-label">Email</label>
          <div class="col-sm-9">
            <input type="email" class="form-control" id="inputEmail3" name="email">
          </div>
        </div>

        <div class="row mb-4">
          <label for="inputEmail3" class="col-sm-3 col-form-label">Password</label>
          <div class="col-sm-9">
            <input type="password" class="form-control" id="inputEmail3" name="password">
          </div>
        </div>

        <div class="form-group">
          <a href="" class="tx-info tx-12 d-block mg-t-10">Forgot password?</a>
        </div><!-- form-group -->
        <button type="submit" class="btn btn-info btn-block" style="cursor: pointer" name="Login">Sign In</button>
        </form>
        
      </div><!-- login-wrapper -->
     </div>
    </div><!-- d-flex -->

    <script src="lib/jquery/jquery.js"></script>
    <script src="lib/popper.js/popper.js"></script>
    <script src="lib/bootstrap/bootstrap.js"></script>

  </body>
</html>
